package com.TheKiranacademy.thekiranacademy12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Thekiranacademy12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
